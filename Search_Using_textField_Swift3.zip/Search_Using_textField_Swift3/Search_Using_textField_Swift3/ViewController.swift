//
//  ViewController.swift
//  Search_Using_textField_Swift3
//
//  Created by Aman Aggarwal on 3/20/17.
//  Copyright © 2017 ClickApps. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var txtSearchBar: UITextField!
    @IBOutlet weak var tblCountries: UITableView!
    var countriesArray:[String] = Array()
    var searchedArray:[String] = Array()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        countriesArray.append("India")
        countriesArray.append("Australia")
        countriesArray.append("New Zealand")
        countriesArray.append("France")
        countriesArray.append("United Kingdom")
        countriesArray.append("Belarus")
        countriesArray.append("Canada")
        countriesArray.append("USA")
        countriesArray.append("Mexico")
        countriesArray.append("Argentina")
        countriesArray.append("Slovakia")

        searchedArray = countriesArray
        
        tblCountries.delegate =  self
        tblCountries.dataSource = self
        
        txtSearchBar.addTarget(self, action: #selector(searchRecordsAsPerText(_ :)), for: .editingChanged)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func searchRecordsAsPerText(_ textfield:UITextField) {
        searchedArray.removeAll()
        if textfield.text?.characters.count != 0 {
            for strCountry in countriesArray {
                let range = strCountry.lowercased().range(of: textfield.text!, options: .caseInsensitive, range: nil,   locale: nil)
                
                if range != nil {
                    searchedArray.append(strCountry)
                }
            }
        } else {
            searchedArray = countriesArray
        }
        
        tblCountries.reloadData()
    }


    
    //MARK:- UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        return searchedArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "Identifier")
        if cell == nil {
            cell = UITableViewCell(style: .default, reuseIdentifier: "Identifier")
        }
        cell?.textLabel?.text = searchedArray[indexPath.row]
        return cell!
    }

}

