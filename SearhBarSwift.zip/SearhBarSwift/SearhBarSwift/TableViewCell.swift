//
//  TableViewCell.swift
//  SearhBarSwift
//
//  Created by Mac on 15/09/19.
//  Copyright © 2019 Mac. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

     @IBOutlet weak var lblgenre: UILabel!
     @IBOutlet weak var lblname: UILabel!
     @IBOutlet weak var lblyear: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
