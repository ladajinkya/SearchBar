//
//  SearchVC.swift
//  SearhBarSwift
//
//  Created by Mac on 15/09/19.
//  Copyright © 2019 Mac. All rights reserved.
//

import UIKit

class SearchVC: UIViewController,UISearchBarDelegate,UITableViewDataSource,UITableViewDelegate {
     @IBOutlet weak var searchBar:UISearchBar!
    var dataArr : [[String : Any]]=[]
    var filteredArr : [[String : Any]]=[]
    var isFiltered :Bool = false
     @IBOutlet weak var Table: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        Table.delegate = self
        Table.dataSource = self
        searchBar.delegate = self
         dataArr = [
            ["name" :  "The Godfather",
             "genre" :  "Crime",
             "year" :  "1972" ],
            
            ["name" :  "The usual suspects",
             "genre" :  "Crime",
             "year" :  "1994" ],
            
            ["name" :  "Sicario 2:Soladado",
             "genre" :  "Crime",
             "year" :  "2018" ],
            
            ["name" :  "The Avengers",
             "genre" :  "Action",
             "year" :  "2012" ],
            
            ["name" :  "Mad Max:Fury Road",
             "genre" :  "action",
             "year" :  "2015" ],
            
            ["name" :  "Kill Bill:Volume 1",
             "genre" :  "Ation",
             "year" :  "2008" ],
            
            ["name" :  "American Pie",
             "genre" :  "comedy",
             "year" :  "1999" ],
            
            ["name" :  "Dumb and Dumber",
             "genre" :  "Comedy",
             "year" :  "1994" ],
            
            ["name" :  "The Dictator",
             "genre" :  "comedy",
             "year" :  "2012" ],
            
            ["name" :  "Titanic",
             "genre" :  "Romance",
             "year" :  "1997" ],
            
            ["name" :  "When happy met sally",
             "genre" :  "Romantic",
             "year" :  "1989" ],
            
            ["name" :  "10 things i hate about you",
             "genre" :  "romace",
             "year" :  "1999" ],
            
            ["name" :  "It",
             "genre" :  "Horror",
             "year" :  "2017" ],
            
            ["name" :  "Grudge",
             "genre" :  "Horror",
             "year" :  "2004" ],
            
            ["name" :  "Saw",
             "genre": "Horror",
             "year" :  "2004" ]
        ]

        // Do any additional setup after loading the view.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isFiltered
        {
             return filteredArr.count;
        }
        else
        {
             return dataArr.count;
        }
       
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.Table.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        if isFiltered
        {
            let filteredItem = filteredArr[indexPath.row]as NSDictionary
//            let filteredItem1 = filteredArr[indexPath.row]["name"]
//            let filteredItem2 = filteredArr[indexPath.row]["genre"]
//            let filteredItem3 = filteredArr[indexPath.row]["year"]
//            print(filteredItem1!)
//            print(filteredItem2!)
//            print(filteredItem3!)
            print(filteredItem)
            cell.lblname.text = filteredItem["name"] as? String
            cell.lblgenre.text = filteredItem["genre"] as? String
            cell.lblyear.text = filteredItem["year"] as? String
        }
        else
        {
            let item = dataArr[indexPath.row]as NSDictionary
            
            cell.lblname.text = item["name"] as? String
            cell.lblgenre.text = item["genre"] as? String
            cell.lblyear.text = item["year"] as? String
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        searchBar.text = ""
        isFiltered = false
        self.Table.reloadData()
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if(searchText.isEmpty)
        {
            isFiltered = false
            self.Table.reloadData()
        }
        else
        {
            isFiltered = true
            let resultPredicate = NSPredicate(format: "name contains[c] %@ OR genre contains[c] %@ OR year contains[c] %@", searchText,searchText,searchText)
            filteredArr = dataArr.filter { resultPredicate.evaluate(with: $0) }
           // print("filteredarr = \(filteredArr)")
        }
        self.Table.reloadData()
    }
   

}
